function updateClock(){const now=new Date();const s=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(now);const el=document.getElementById('currentClock');if(el)el.textContent=s+' WIB'}
updateClock();setInterval(updateClock,1000);
'use strict';
let cart=[];
const seller='62881025002429', payment='0882008865036';
function money(n){return 'Rp '+Number(n).toLocaleString('id-ID')}
function isServiceOpen(){
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());
  const h=Number(parts.find(x=>x.type==='hour').value), m=Number(parts.find(x=>x.type==='minute').value);
  const t=h*60+m; return t>=540 && t<1020;
}
function showClosedModal(){const m=document.getElementById('closedModal');if(m){m.classList.add('show');m.setAttribute('aria-hidden','false');document.body.classList.add('closed-open');}}
function closeClosedModal(){const m=document.getElementById('closedModal');if(m){m.classList.remove('show');m.setAttribute('aria-hidden','true');document.body.classList.remove('closed-open');}}
function closedNotice(){showClosedModal();}
function addToCart(name,period,price){
  if(!isServiceOpen()){closedNotice();return;}
  const item=cart.find(x=>x.name===name&&x.period===period);
  if(item)item.qty++; else cart.push({name,period,price:Number(price),qty:1});
  renderCart();
  document.getElementById('keranjang').scrollIntoView({behavior:'smooth',block:'center'});
}
function changeQty(i,d){cart[i].qty+=d;if(cart[i].qty<=0)cart.splice(i,1);renderCart()}
function total(){return cart.reduce((s,x)=>s+x.price*x.qty,0)}
function renderCart(){
 const box=document.getElementById('cartItems');
 document.getElementById('cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0)+' item';
 document.getElementById('cartTotal').textContent=money(total());
 if(!cart.length){box.innerHTML='<p class="empty">Keranjang masih kosong.</p>';return}
 box.innerHTML=cart.map((x,i)=>`<div class="cartrow"><div><b>${x.name}</b><small>${x.period} • ${money(x.price)}</small></div><div class="qty"><button type="button" onclick="changeQty(${i},-1)">−</button><b>${x.qty}</b><button type="button" onclick="changeQty(${i},1)">+</button></div><strong>${money(x.price*x.qty)}</strong></div>`).join('');
}
function openCheckout(){if(!isServiceOpen()){closedNotice();return}if(!cart.length){alert('Keranjang masih kosong. Pilih layanan terlebih dahulu.');return}document.getElementById('summary').innerHTML=cart.map(x=>`${x.name} × ${x.qty} — ${money(x.price*x.qty)}`).join('<br>')+`<hr><b>Total Checkout: ${money(total())}</b>`;document.getElementById('formStep').hidden=false;document.getElementById('payStep').hidden=true;document.getElementById('modal').classList.add('show')}
function closeCheckout(){document.getElementById('modal').classList.remove('show')}
function showPayment(){const n=document.getElementById('name').value.trim(),p=document.getElementById('phone').value.trim();if(!n||!p){alert('Isi nama dan nomor WhatsApp terlebih dahulu.');return}window.checkoutCustomer={n,p};document.getElementById('formStep').hidden=true;document.getElementById('payStep').hidden=false}
function copyNumber(){navigator.clipboard?navigator.clipboard.writeText(payment).then(()=>alert('Nomor berhasil disalin.')).catch(()=>alert(payment)):alert(payment)}

function updateCheckoutPayment(){const m=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA';const q=document.getElementById('checkoutQrisInfo');if(q)q.hidden=m!=='QRIS'}

function cancelOrder(){
  const ok=confirm('Batalkan pesanan ini? Item di keranjang akan dihapus.');
  if(!ok)return;
  cart=[];
  window.checkoutCustomer=null;
  const name=document.getElementById('name');
  const phone=document.getElementById('phone');
  if(name)name.value='';
  if(phone)phone.value='';
  closeCheckout();
  renderCart();
  alert('Pesanan berhasil dibatalkan.');
}
function confirmOrder(){if(!isServiceOpen()){closedNotice();return}const c=window.checkoutCustomer||{n:'-',p:'-'},method=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA',items=cart.map(x=>`• ${x.name} × ${x.qty} = ${money(x.price*x.qty)}`).join('%0A');const msg=`Halo Rakzz-Prst 👋%0A%0ASaya ingin memesan:%0A${items}%0A%0A• Total Checkout: ${money(total())}%0A• Nama: ${c.n}%0A• WhatsApp: ${c.p}%0A• Metode Pembayaran: ${method}%0A• Nomor pembayaran: ${payment}%0A%0ASaya sudah melakukan pembayaran. Mohon konfirmasi pesanan saya.`;window.open(`https://wa.me/${seller}?text=${msg}`,'_blank');
}
renderCart();

function updateServiceStatus(){
 const now=new Date();
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(now);
 const hour=Number(parts.find(x=>x.type==='hour').value);
 const minute=Number(parts.find(x=>x.type==='minute').value);
 const total=hour*60+minute;
 const start=9*60, end=17*60;
 const el=document.getElementById('serviceStatus'), text=document.getElementById('statusText');
 if(!el||!text)return;
 const active=total>=start && total<end;
 el.classList.toggle('active',active); el.classList.toggle('inactive',!active);
 text.textContent=active?'● PELAYANAN SEDANG AKTIF':'● PELAYANAN SEDANG TIDAK AKTIF';
}
updateServiceStatus(); setInterval(updateServiceStatus,60000);

const bgMusic=document.getElementById('bgMusic');
const musicToggle=document.getElementById('musicToggle');
const musicState=document.getElementById('musicState');
function toggleMusic(){if(!bgMusic)return;if(bgMusic.paused){bgMusic.play().then(()=>{musicToggle.textContent='❚❚';musicState.textContent='Sedang diputar'}).catch(()=>{musicState.textContent='Tekan lagi untuk memutar'});}else{bgMusic.pause();musicToggle.textContent='▶';musicState.textContent='Dijeda';}}
bgMusic?.addEventListener('ended',()=>{musicToggle.textContent='▶';musicState.textContent='Selesai'});

function updateGreeting(){
 const now=new Date();
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(now);
 const h=Number(parts.find(x=>x.type==='hour').value);
 const el=document.getElementById('greeting'); if(!el)return;
 let greeting;
 if(h>=4&&h<11) greeting='Selamat pagi 👋';
 else if(h>=11&&h<15) greeting='Selamat siang 👋';
 else if(h>=15&&h<18) greeting='Selamat sore 👋';
 else greeting='Selamat malam 👋';
 el.textContent=greeting+' — Selamat datang di Rakzz-Prst!';
}
updateGreeting(); setInterval(updateGreeting,60000);

function updatePrayerStatus(){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date());
 const h=Number(parts.find(x=>x.type==='hour').value), m=Number(parts.find(x=>x.type==='minute').value), t=h*60+m;
 const prayers=[['Subuh',240,359,'04:00'],['Dzuhur',720,899,'12:00'],['Ashar',900,1079,'15:00'],['Maghrib',1080,1139,'18:00'],['Isya',1140,1439,'19:00'],['Isya',0,239,'19:00']];
 const current=prayers.find(x=>t>=x[1]&&t<=x[2]);
 const strip=document.getElementById('waktu-sholat');
 if(!strip)return;
 if(current){
   strip.hidden=false;
   document.getElementById('prayerTitle').textContent='Waktu Sholat';
   document.getElementById('prayerName').textContent=current[0];
   document.getElementById('prayerTime').textContent=current[3]+' WIB';
   document.getElementById('prayerNow').textContent='Sekarang: '+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+' WIB';
   document.getElementById('prayerStatusText').textContent='Waktu '+current[0]+' sedang berlangsung';
 }else{
   strip.hidden=true;
 }
}
updatePrayerStatus();setInterval(updatePrayerStatus,60000);


function makeTransactionId(){return 'RZ'+Date.now().toString().slice(-8)}
function loadTransactionHistory(){
  let history=JSON.parse(localStorage.getItem('rakzzTransactionHistory')||'[]');
  // Migrate an older single transaction into the history once.
  if(!history.length){
    const old=JSON.parse(localStorage.getItem('rakzzTransaction')||'null');
    if(old){history=[old];localStorage.setItem('rakzzTransactionHistory',JSON.stringify(history));localStorage.removeItem('rakzzTransaction');}
  }
  return Array.isArray(history)?history:[];
}
let transactionHistory=loadTransactionHistory();
function createTransaction(method){
 const c=window.checkoutCustomer||{n:'-',p:'-'};
 const tx={id:makeTransactionId(),name:c.n,phone:c.p,total:total(),method,createdAt:new Date().toISOString(),items:cart.map(x=>({name:x.name,period:x.period,price:x.price,qty:x.qty}))};
 transactionHistory.unshift(tx);
 transactionHistory=transactionHistory.slice(0,30);
 localStorage.setItem('rakzzTransactionHistory',JSON.stringify(transactionHistory));
 renderTransactionHistory();
 return tx;
}
function renderTransactionHistory(){
 const empty=document.getElementById('transactionEmpty'), box=document.getElementById('transactionHistory');
 if(!empty||!box)return;
 if(!transactionHistory.length){empty.hidden=false;box.innerHTML='';return}
 empty.hidden=true;
 box.innerHTML=transactionHistory.map(tx=>`<div class="history-card"><div class="history-top"><div><span class="tx-label">ID TRANSAKSI</span><b>${tx.id}</b></div><span class="history-method">${tx.method||'-'}</span></div><div class="history-details"><div><small>Nama</small><b>${tx.name||'-'}</b></div><div><small>Total</small><b>${money(tx.total)}</b></div><div><small>Metode</small><b>${tx.method||'-'}</b></div><div><small>Tanggal</small><b>${new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',dateStyle:'short',timeStyle:'short'}).format(new Date(tx.createdAt))} WIB</b></div></div><div class="history-items">${(tx.items||[]).map(x=>`<div><span>${x.name} × ${x.qty}<small>${x.period}</small></span><b>${money(x.price*x.qty)}</b></div>`).join('')}</div></div>`).join('');
}
function clearTransactionHistory(){
 if(confirm('Hapus seluruh riwayat transaksi di perangkat ini?')){transactionHistory=[];localStorage.removeItem('rakzzTransactionHistory');localStorage.removeItem('rakzzTransaction');renderTransactionHistory();}
}
renderTransactionHistory();
const originalShowPayment=showPayment;
showPayment=function(){originalShowPayment();}
const originalConfirmOrder=confirmOrder;
confirmOrder=function(){
 if(!isServiceOpen()){closedNotice();return}
 const method=document.querySelector('input[name=paymentMethod]:checked')?.value||'DANA';
 createTransaction(method);
 originalConfirmOrder();
};
renderTransactionHistory();
