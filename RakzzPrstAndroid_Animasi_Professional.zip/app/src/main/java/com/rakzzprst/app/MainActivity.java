package com.rakzzprst.app;
import android.app.*; import android.os.*; import android.view.*; import android.view.animation.*; import android.content.*; import android.net.*; import android.webkit.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity{
 WebView w;
 public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setAlpha(0f); setContentView(w); w.animate().alpha(1f).setDuration(650).setStartDelay(120).start(); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(true); w.setWebChromeClient(new WebChromeClient()); w.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v,String u){if(u.startsWith("http")){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));return true;}return false;}}); w.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}