

## Animasi pembuka
Splash screen menampilkan logo Rakzz-Prst dengan efek fade/scale, floating, loading bar, dan transisi fade halus ke halaman utama.
